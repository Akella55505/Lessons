import org.json.simple.JSONObject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class JSONFileWriter implements OutFileWriter{
    private String outPath;

    public JSONFileWriter(String outPath) {
        this.outPath = outPath;
    }

    @Override
    public void writeFile(ArrayList<String> inFileData) { //
        /*
        тут у меня уже хватило мозгов найти норм библиотеку
        да и это было не особо сложно, изначально я пробовал
        Джексон и Гсон, но потом, из-за более простого
        синтаксиса перешёл на джсон-симпл
         */
        JSONObject jsonObject = new JSONObject(); // создаю объект джсон
        for(int i = 0; i < inFileData.size(); i = i + 2){ // я решил начать с райтера так, как его было быстрее написать
            jsonObject.put(inFileData.get(i), inFileData.get(i+1)); // ложу в джсон объект данные из листа
        }
        try {
            FileWriter file = new FileWriter(outPath);
            file.write(jsonObject.toJSONString()); // записываю в виде строки ибо не нашёл способа с табуляциями и т.д.
            file.close(); // закрываю райтер
        } catch (IOException e) {
            e.printStackTrace();
        } // дальше смотреть ДЖСОНРидер
    }
}
