import java.util.ArrayList;

public interface OutFileWriter {
    void writeFile(ArrayList<String> inFileData);
}
