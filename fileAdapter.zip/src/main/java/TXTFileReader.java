import java.io.*;
import java.util.ArrayList;

public class TXTFileReader implements InFileReader {
    private String path;

    public TXTFileReader(String path) {
        this.path = path;
    }

    @Override
    public ArrayList<String> readFile() {
        File file = new File(path);
        if (file.exists() == false){
            System.err.println("File does not exist");
            System.exit(0); // ошибка
        }
        ArrayList<String> parts = new ArrayList<String>(); // это лист "части", он будет присутствовать во всех ридерах
        final String del = ":"; // этот лист я потом передаю, как inFileData назвал я его по другому просто потому что(хз)
        try (BufferedReader br = new BufferedReader(new FileReader(file))) // ридер
        {
            String line;
            /*
            Я для себя определил, что в ТХТ файлы будут выглядеть в виде
            Ключ:(пробел)значение
            чтобы устоять определённую форму, как всё будет читаться и писаться
             */
            while ((line = br.readLine()) != null) {
                String[] arr = line.split(del);
                arr[1] = arr[1].substring(1); // собственно читаю и добавляю в "части" части файла, для
                parts.add(arr[0]); // будущего добавления их в лист.
                parts.add(arr[1]);  // Использую substring, для тогоЮ чтобы убрать пробел перед добавлением
            }
        } catch (IOException e) {
            e.printStackTrace();
        } // исключение
        return parts; // возвращаю лист назад в Адаптер
    } // Дальше смотреть ТХТРайтер
}
