import java.util.Scanner;

public class Main {
    public static void main(String[] args) { /*
    изначально я создал два интерфейса
    для ридеров и райтеров, потому что там термин
    есть, который я никак не запомню, ну в общем там метод будет один у разных
    классов и всё будет круто
    */
        Scanner in = new Scanner(System.in); // тут думаю всё ясно
        String path = in.nextLine();
        String outPath = in.nextLine();
        Adapter adapter = new Adapter(path, outPath);
        adapter.adapt();
        in.close(); // дальше смотреть Адаптер
    }
}
