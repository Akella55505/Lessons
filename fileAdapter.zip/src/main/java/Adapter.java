import java.util.ArrayList;

public class Adapter {
    private String path;
    private String outPath;
    public Adapter(String path, String outPath){
        this.path = path;
        this.outPath = outPath;
    }
    void adapt(){
        InFileReader inFile;
        OutFileWriter outFile; // создаю объекты введённого и выведенного файла, для более позднего определения расширений
        final String del =  "\\."; // разделитель
        String[] inExtArr = path.split(del);
        String inExt = inExtArr[inExtArr.length-1]; // получил переменную с форматом файла
        if (inExt.equals("txt")){
            inFile = new TXTFileReader(path);
        } else if(inExt.equals("json")) {
            inFile = new JSONFileReader(path);
        } else if(inExt.equals("xml")){
            inFile = new XMLFileReader(path); // в зависимости от расширения создаю нужный ридер
        } else{
            System.err.println("Non-supported extension");
            inFile = new XMLFileReader(path);;
            System.exit(0); // ошибка
        }
        ArrayList<String> inFileData = inFile.readFile(); /*
        в эрэйлист я потом буду переводить все форматы,
        для поздней их адаптации. Через время я понял,
        что есть огромное количество способов
        сделать это легче, но код уже было переписывать лень
        и я подстроился под то что придумал первым.
        */
        String[] outExtArr = outPath.split(del);
        String outExt = outExtArr[outExtArr.length-1]; // расширение для преоразования
        if (outExt.equals("txt")){
            outFile = new TXTFileWriter(outPath);
            outFile.writeFile(inFileData);
        } else if(outExt.equals("json")) {
            outFile = new JSONFileWriter(outPath);
            outFile.writeFile(inFileData);
        } else if(outExt.equals("xml")){
            outFile = new XMLFileWriter(outPath); // создаю райтер для файла, который будет создан
            outFile.writeFile(inFileData);
        } else if(outExt.equals("")){
            if(!inExt.equals("txt")){
                outFile = new TXTFileWriter("src\\test\\resources\\txtfile.txt");
                outFile.writeFile(inFileData);
            }
            if(!inExt.equals("json")){
                outFile = new JSONFileWriter("src\\test\\resources\\jsonfile.json");
                outFile.writeFile(inFileData);
            }
            if(!inExt.equals("xml")){
                outFile = new XMLFileWriter("src\\test\\resources\\xmlfile.xml");
                outFile.writeFile(inFileData);
            } /*
            То самое "со звёздочкой", я решил не заморачиваться с доп. переменными,
            поэтому просто назвал файлы по форматам и кинул в ресурсы проэкта
            */
        } else{
            System.err.println("Non-supported path-type or extension");
            System.exit(0); // ошибка
        } // дальше смотреть ТХТРидер
    }
}
