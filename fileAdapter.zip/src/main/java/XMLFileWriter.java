import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class XMLFileWriter implements OutFileWriter{
    private String outPath;

    public XMLFileWriter(String outPath) {
        this.outPath = outPath;
    }

    @Override
    public void writeFile(ArrayList<String> inFileData) {
        try {
            FileWriter file = new FileWriter(outPath); // тут ничего особенного, просто таким же
            file.write("<?xml version=\"1.0\"?>\n"); // гениальным(нет) способом я решил записывать
            file.write("<"+inFileData.get(1)+">\n"); // файл на диск, прописывая все части тегов и т.п. вручную
            for (int i = 2; i <= inFileData.size()-2; i = i + 2) { // ибо с нахождением библиотеки я не справился(тупой х3)
                file.write("\t<"+inFileData.get(i)+">"+inFileData.get(i+1)+"</"+inFileData.get(i)+">\n");
            }
            file.write("</"+inFileData.get(1)+">");
            file.close(); // закрываю файл
        } catch (IOException e) {
            e.printStackTrace();
        } // дальше смотреть ДЖСОНРайтер
    }
}
