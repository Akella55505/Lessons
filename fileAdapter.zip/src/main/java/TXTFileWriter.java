import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TXTFileWriter implements OutFileWriter{
    private String outPath;

    public TXTFileWriter(String outPath) {
        this.outPath = outPath;
    } // передаю путь вывода файла

    @Override
    public void writeFile(ArrayList<String> inFileData) {
        try {
            FileWriter file = new FileWriter(outPath); // райтер
            for (int i = 0; i < inFileData.size(); i = i + 2) {
                file.write(inFileData.get(i)+": "+inFileData.get(i+1)+"\n");
            } // собственно в цикле вывожу в документ данные с листа в виде своеобразной "таблицы"
            file.close(); // закрываю файл
        } catch (IOException e) {
            e.printStackTrace(); // исключение
        }
    } // дальше смотреть ХМЛРидер
}
