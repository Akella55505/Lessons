import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class JSONFileReader implements InFileReader {
    private String path;

    public JSONFileReader(String path) {
        this.path = path;
    }

    @Override
    public ArrayList<String> readFile() {
        /*
        И вот под конец передо мной стала задача, как прочитать и перевести джсон именно в лист,
        поскольку весь код кроме этого класса уже был написал и менять формат передачи я уже не собирался.
        Так что я решил прочитать файл, потом перевести его в строку и...
         */
        ArrayList<String> parts = new ArrayList<>();
        JSONParser jsonParser = new JSONParser();
        try {
            if (new File(path).exists() == false){
                System.err.println("File does not exist");
                System.exit(0); // ещё одна ошибка
            }
            FileReader reader = new FileReader(path);
            String jsonString = String.valueOf(jsonParser.parse(reader));
            System.out.println(jsonString);
            jsonString = jsonString.replaceAll("\\{", ""); // снова пользоваться этим костыльным
            jsonString = jsonString.replaceAll("\"", ""); // методом с заменой знаковых символов
            jsonString = jsonString.replaceAll("}", ""); // и разделением значений на массив
            jsonString = jsonString.replaceAll(":", "/"); // для позднего добавления в лист
            jsonString = jsonString.replaceAll(",", "/");
            System.out.println(jsonString);
            String[] arr = jsonString.split("/");
            for(int i = 0; i < arr.length; i = i + 2){
                parts.add(arr[i]);
                parts.add(arr[i+1]); // тут добавляю в лист
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace(); // разные исключения
        }
        return parts;
    } // ща соберу джарник, залью на гит и ложусь спать, хз, какой у тебя график, но я с 6 утра обычно на ногах,
} // а уроки у меня начинаются в 8:30, так что до этого времени можешь мне отписать или позвонить
// П.С.: с лицензией я решил не заморачиваться и просто брать триалку на сгенерированную поту каждые
// две недели или сколько она там длится