import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class XMLFileReader implements InFileReader {
    private String path;

    public XMLFileReader(String path) {
        this.path = path;
    }

    @Override
    public ArrayList<String> readFile() { // тут было очень плохо
        File file = new File(path); // код тут ужасный, как и метод, который я придумал в принципе
        /*
        Если в кратце, я начал гуглить способы парсить ХМЛ и наткнулся на САХ и ДОМ,
        в чём разница, конечно, я понятия не имел и загуглить это я уже не додумался(тупой).
        Я взялся смотреть туториалы по ДОМ и встретился с такой проблемой:
        я не мог вывести из файла ключ(тег), а только его значение. Я
        стал гуглить различные библиотеки и способы, но опять же не нашёл подходящего
        для меня решение(тупой х2). В итоге дело было уже под вечер и меня неплохо жмыхнуло, я
        решил прочитать его бафередридером и просто удалить из строки лишнее, позже разделив её.
        На следующий день я уже не собирался это переписывать, поскольку, хоть и очень костыльно, но
        работало. Так же к слову я в эрэйлист всегда первым элементом добавляю Root, поскольку
        в ХМЛ без корневого тега никак, так что пришлось его добавить
         */
        if (file.exists() == false){
            System.err.println("File does not exist");
            System.exit(0);
        } // ошибка
        ArrayList<String> parts = new ArrayList<String>(); // опять части
        try (BufferedReader br = new BufferedReader(new FileReader(file))) // тут началось
        {
            br.readLine();
            String line;
            final String del = "\\\\";
            parts.add("Root"); // собственно Root
            String rootKey = br.readLine();
            rootKey = rootKey.replaceAll(">", "");
            rootKey = rootKey.replaceAll("<", "");
            rootKey = rootKey.replaceAll("/", "");
            parts.add(rootKey); // тут я нашёл корневой тег и добавил его в лист
            boolean bool = true; // переменная, для того, чтобы позже при надобности выйти из цикла
            while ((line = br.readLine()) != null && bool == true) { // первое условие можно было убрать, но
                line = line.replaceAll(">", "\\\\"); // ничего бы особо не поменялось, перекинь
                line = line.replaceAll("<", "\\\\"); // бы я его в цикл, так что я просто поставил
                line = line.replaceAll("/", ""); // тут "и"
                String[] arr = line.split(del);
                if (arr[1].equals(rootKey)){
                    bool = false; // проверка на последнюю строку, поскольку в ХМЛ в последней строке стоит корневой тег
                } else {
                    parts.add(arr[1]);
                    parts.add(arr[2]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // исключение
        }
        return parts;
    } // Дальше ХМЛРайтер
}
