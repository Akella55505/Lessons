import java.util.ArrayList;

public interface InFileReader {
    ArrayList<String> readFile();
}
