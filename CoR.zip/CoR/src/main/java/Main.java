import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        System.out.println("This is a Chain of Responsibility example");

        Scanner scanner = new Scanner(System.in);
        Integer digit = null;

        while(digit == null){
            System.out.println("Insert an even 3-digit integer with number 0 on any position:");
            digit = scanner.nextInt();
        }

        Checker checker = new ThreeDigitChecker();
        checker.join(new SecondNumberChecker()).join(new DivisionChecker());
        checker.check(digit);
    }
}
