import java.util.Arrays;

public class SecondNumberChecker extends Checker{

    @Override
    public boolean check(Integer digit) {
        if (Arrays.asList(String.valueOf(digit).split("")).contains("0")) {
            System.out.println("SecondNumber check...\nSuccess!");
            return checkNext(digit);
        }
        System.out.println("SecondNumber check...");
        System.out.println("Fail");
        return true;
    }
}
