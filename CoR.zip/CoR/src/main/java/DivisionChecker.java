public class DivisionChecker extends Checker{

    @Override
    public boolean check(Integer digit){
        if(digit % 2 == 0){
            System.out.println("Division check...\nSuccess!");
            return checkNext(digit);
        }
        System.out.println("Division check...");
        System.out.println("Fail");
        return false;
    }
}
