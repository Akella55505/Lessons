public abstract class Checker {
    private Checker next;

    public Checker join(Checker next){
        this.next = next;
        return next;
    }

    public abstract boolean check(Integer digit);

    protected boolean checkNext(int digit){
        if (next == null){
            System.out.println("Congrats on completing this social experiment!!!");
            return true;
        }
        return next.check(digit);
    }
}