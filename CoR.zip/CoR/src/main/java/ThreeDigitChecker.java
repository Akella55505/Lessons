public class ThreeDigitChecker extends Checker{

    @Override
    public boolean check(Integer digit) {
        if (digit >= 100 && digit<1000){
            System.out.println("ThreeDigit check...\nSuccess!");
            return checkNext(digit);
        }
        System.out.println("ThreeDigit check...");
        System.out.println("Fail");
        return true;
    }
}
